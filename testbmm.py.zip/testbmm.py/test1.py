from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Mở trình duyệt và cài đặt thời gian chờ mặc định
driver = webdriver.Chrome()
driver.maximize_window()
driver.implicitly_wait(10) # Đỡ phải viết WebDriverWait nhiều lần

# Info acc test (lấy trên trang chủ nếu acc cũ bị đổi pass)
user_test = "1303"
pass_test = "Guru99"
url_trang_chu = "https://demo.guru99.com/V4/index.php"
url_admin = "https://demo.guru99.com/V4/manager/Managerhomepage.php"

def tat_alert_neu_co():
    # Hàm cùi bắp để bấm OK mấy cái popup báo lỗi của trang
    try:
        alert = driver.switch_to.alert
        noidung = alert.text
        alert.accept()
        return noidung
    except:
        return ""

def test_truy_cap_link_admin():
    print("\n--- TC1: Thử gõ thẳng link admin xem có vào được ko ---")
    driver.get(url_admin)
    time.sleep(5) # Đợi xíu cho trang load
    
    tat_alert_neu_co()
    
    # Check url hiện tại hoặc chữ trên web
    if "Managerhomepage" in driver.current_url or "Manager Id" in driver.page_source:
        print("TOANG: Không cần login vẫn vô được trang quản trị!")
    else:
        print("Pass: Web đã đá văng ra ngoài.")

def test_back_sau_khi_logout():
    print("\n--- TC2: Check xem logout xong bấm Back có vào lại đc ko ---")
    driver.get(url_trang_chu)
    
    try:
        # Login vô trong
        driver.find_element(By.NAME, "uid").send_keys(user_test)
        driver.find_element(By.NAME, "password").send_keys(pass_test)
        driver.find_element(By.NAME, "btnLogin").click()
        time.sleep(2)
        
        # Bấm nút Log out
        driver.find_element(By.LINK_TEXT, "Log out").click()
        tat_alert_neu_co() 
        time.sleep(5)
        
        # Giả vờ bấm nút Back trên trình duyệt
        print("Đang test bấm Back...")
        driver.back()
        time.sleep(5)
        
        if "Managerhomepage" in driver.current_url:
            print("  Nút Back cho phép xài tiếp session cũ.")
        else:
            print("  Session đã chết sau khi logout.")
            
    except Exception as e:
        print("Lỗi chạy TC2, check lại mạng hoặc acc:", e)

def test_xss_coban():
    print("\n--- TC3: Bơm thử mã XSS vào ô User ---")
    driver.get(url_trang_chu)
    
    payload_xss = "<script>alert('Bi_Hack_Roi')</script>"
    
    try:
        o_user = driver.find_element(By.NAME, "uid")
        o_user.clear()
        o_user.send_keys(payload_xss)
        driver.find_element(By.NAME, "btnLogin").click()
        
        time.sleep(2)        
        
        thong_bao = tat_alert_neu_co()
        if thong_bao == "BiHackRoi":
            print(" Lỗi XSS: Trang web đã chạy đoạn script lạ!")
        else:
            print(" Pass: Web có filter ký tự đặc biệt.")
            
    except Exception as e:
        print("Lỗi TC3:", e)

def test_sqli_form_login():
    print("\n--- TC4: Test SQL Injection bypass login ---")
    driver.get(url_trang_chu)
    
    # Mã SQLi kinh điển
    payload_sqli = "' OR '1'='1"
    
    try:
        driver.find_element(By.NAME, "uid").send_keys(payload_sqli)
        driver.find_element(By.NAME, "password").send_keys("matkhaugiacungduoc")
        driver.find_element(By.NAME, "btnLogin").click()
        
        time.sleep(2)
        tat_alert_neu_co() 
        
        html_page = driver.page_source.lower()
        if "managerhomepage" in driver.current_url.lower():
            print(" Nguy hiểm: Bypass được login bằng SQLi!")
        elif "sql syntax" in html_page or "database error" in html_page:
            print(" Lỗi: Web in hẳn lỗi database ra màn hình (Dễ bị khai thác thêm).")
        else:
            print(" Pass: Input được mã hóa an toàn.")
            
    except Exception as e:
        print("Lỗi TC4:", e)

# Chạy lần lượt các test case
if __name__ == "__main__":
    driver.get(url_trang_chu)
    time.sleep(5)
    test_truy_cap_link_admin()
    test_xss_coban()
    test_sqli_form_login()
    test_back_sau_khi_logout() # Để cái này cuối cùng cho tiện luồng login/logout
    print("\nChạy xong hết các case!")
    time.sleep(5)
    driver.quit()