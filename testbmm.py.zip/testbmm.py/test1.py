from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# --- CẤU HÌNH THÔNG TIN ---
USER_TEST = "1303"
PASS_TEST = "Guru99"
URL_LOGIN = "https://demo.guru99.com/V4/index.php"
URL_ADMIN = "https://demo.guru99.com/V4/manager/Managerhomepage.php"

# Danh sách các Case bảo mật
# logic_type: dùng để phân loại cách xử lý riêng cho từng loại test
security_testdata = [
    {
        "id": "BM001", 
        "name": "Truy cập thẳng Admin", 
        "url": URL_ADMIN, 
        "user": "", "pass": "", 
        "logic_type": "direct_url"
    },
    {
        "id": "BM002", 
        "name": "Test XSS User-ID", 
        "url": URL_LOGIN, 
        "user": "<script>alert('Bi_Hack_Roi')</script>", "pass": "123", 
        "logic_type": "normal_login"
    },
    {
        "id": "BM003", 
        "name": "Test SQL Injection", 
        "url": URL_LOGIN, 
        "user": "' OR '1'='1", "pass": "any_pass", 
        "logic_type": "normal_login"
    },
    {
        "id": "BM004", 
        "name": "Test Back Button sau Logout", 
        "url": URL_LOGIN, 
        "user": USER_TEST, "pass": PASS_TEST, 
        "logic_type": "logout_back"
    }
]

def handle_alert(driver):
    try:
        alert = driver.switch_to.alert
        text = alert.text
        alert.accept()
        return text
    except:
        return None

def run_security_test():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.implicitly_wait(5)

    for data in security_testdata:
        print(f"\n[+] Đang thực hiện: {data['id']} - {data['name']}")
        driver.get(data['url'])
        time.sleep(2)

        # --- LOGIC 1: Truy cập thẳng link (Broken Access Control) ---
        if data['logic_type'] == "direct_url":
            handle_alert(driver)
            if "Managerhomepage" in driver.current_url or "Manager Id" in driver.page_source:
                print("Kết quả: TOANG - Không login vẫn vào được Admin!")
            else:
                print("Kết quả: PASS - Hệ thống đã chặn truy cập trái phép.")

        # --- LOGIC 2: Các kỹ thuật tấn công qua Form (XSS, SQLi) ---
        elif data['logic_type'] == "normal_login":
            driver.find_element(By.NAME, "uid").send_keys(data['user'])
            driver.find_element(By.NAME, "password").send_keys(data['pass'])
            driver.find_element(By.NAME, "btnLogin").click()
            time.sleep(2)
            
            alert_text = handle_alert(driver)
            html = driver.page_source.lower()
            
            if alert_text == "Bi_Hack_Roi":
                print("Kết quả: LỖI - Script XSS đã thực thi!")
            elif "managerhomepage" in driver.current_url.lower():
                print("Kết quả: NGUY HIỂM - Bypass được Login bằng SQLi!")
            elif "sql syntax" in html:
                print("Kết quả: LỖI - Lộ thông tin Database (SQL Error).")
            else:
                print("Kết quả: PASS - Hệ thống an toàn trước Input này.")

        # --- LOGIC 3: Kiểm tra Session (Logout & Back) ---
        elif data['logic_type'] == "logout_back":
            # Đăng nhập trước
            driver.find_element(By.NAME, "uid").send_keys(data['user'])
            driver.find_element(By.NAME, "password").send_keys(data['pass'])
            driver.find_element(By.NAME, "btnLogin").click()
            time.sleep(2)
            # Logout
            driver.find_element(By.LINK_TEXT, "Log out").click()
            handle_alert(driver)
            time.sleep(2)
            # Thử quay lại
            print("Đang thử bấm Back...")
            driver.back()
            time.sleep(3)
            
            if "Managerhomepage" in driver.current_url:
                print("Kết quả: LỖI - Vẫn dùng được session cũ sau khi Logout!")
            else:
                print("Kết quả: PASS - Session đã bị hủy hoàn toàn.")

    driver.quit()
    print("\n>>> Hoàn thành kiểm thử bảo mật.")

if __name__ == "__main__":
    run_security_test()