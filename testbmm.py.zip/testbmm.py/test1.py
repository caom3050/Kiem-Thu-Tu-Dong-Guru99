from selenium import webdriver
from selenium.webdriver.common.by import By

USER = "1303"
PASS = "Guru99"

driver = webdriver.Chrome()
driver.implicitly_wait(5)

# ===== TEST 1: Truy cập thẳng Admin =====
print("\n[BM001] Truy cập thẳng Admin")
driver.get("https://demo.guru99.com/V4/manager/Managerhomepage.php")

if "Managerhomepage" in driver.current_url:
    print("LỖI - Không login vẫn vào được Admin")
else:
    print("PASS")

# ===== TEST 2: XSS =====
print("\n[BM002] Test XSS")
driver.get("https://demo.guru99.com/V4/index.php")

driver.find_element(By.NAME, "uid").send_keys("<script>alert('hack')</script>")
driver.find_element(By.NAME, "password").send_keys("123")
driver.find_element(By.NAME, "btnLogin").click()

try:
    alert = driver.switch_to.alert
    print(" XSS chạy được")
    alert.accept()
except:
    print("không thể login vào trang chủ")

# ===== TEST 3: SQL Injection =====
print("\n[BM003] Test SQL Injection")
driver.get("https://demo.guru99.com/V4/index.php")

driver.find_element(By.NAME, "uid").send_keys("' OR '1'='1")
driver.find_element(By.NAME, "password").send_keys("123")
driver.find_element(By.NAME, "btnLogin").click()

if "Managerhomepage" in driver.current_url:
    print("nguy hiểm bypass login")
else:
    print("không thể bypass login")

# ===== TEST 4: Logout + Back =====
print("\n[BM004] Test Logout + Back")
driver.get("https://demo.guru99.com/V4/index.php")

# login
driver.find_element(By.NAME, "uid").send_keys(USER)
driver.find_element(By.NAME, "password").send_keys(PASS)
driver.find_element(By.NAME, "btnLogin").click()

# logout
driver.find_element(By.LINK_TEXT, "Log out").click()
driver.switch_to.alert.accept()

# back
driver.back()

if "Managerhomepage" in driver.current_url:
    print("LỖI - Vẫn vào được sau logout")
else:
    print("không vào được sau logout")

driver.quit()