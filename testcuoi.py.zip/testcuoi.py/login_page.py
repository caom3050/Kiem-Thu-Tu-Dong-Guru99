from selenium.webdriver.common.by import By

class TrangDangNhap:
    def __init__(self, trinh_duyet):
        self.trinh_duyet = trinh_duyet

    def mo_trang(self):
        self.trinh_duyet.get("https://demo.guru99.com/V4/")

    def dang_nhap(self, ten_dang_nhap, mat_khau):
        self.trinh_duyet.find_element(By.NAME, "uid").send_keys(ten_dang_nhap)
        self.trinh_duyet.find_element(By.NAME, "password").send_keys(mat_khau)
        self.trinh_duyet.find_element(By.NAME, "btnLogin").click()

    def lay_thong_bao_alert(self):
        try:
            alert = self.trinh_duyet.switch_to.alert
            noi_dung = alert.text
            alert.accept()
            return noi_dung
        except:
            return 0

    def kiem_tra_dang_nhap_thanh_cong(self):
        return "home" in self.trinh_duyet.current_url.lower()

    def lay_loi_form(self):
        try:
            loi_user = self.trinh_duyet.find_element(By.ID, "message23").text
            loi_pass = self.trinh_duyet.find_element(By.ID, "message18").text
            return loi_user + " " + loi_pass
        except:
            return 0