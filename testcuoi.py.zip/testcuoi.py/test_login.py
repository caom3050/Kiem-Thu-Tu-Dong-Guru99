from selenium import webdriver
from login_page import TrangDangNhap
import time

user = "1303"
password = "Guru99"

testcase = [
    {"id": "DN001", "user": user, "pass": password},
    {"id": "DN002", "user": "", "pass": ""},
    {"id": "DN003", "user": "1303", "pass": ""},
    {"id": "DN004", "user": "", "pass": "Guru99"},
    {"id": "DN005", "user": "1303", "pass": "rar"},
    {"id": "DN006", "user": "mng", "pass": "Guru99"},
]

def test():
    trinh_duyet = webdriver.Chrome()
    trang_dang_nhap = TrangDangNhap(trinh_duyet)
    for data in testcase:
        print("\n Testcase: ",data['id'])
        trang_dang_nhap.mo_trang()
        # thực hiện đăng nhập
        trang_dang_nhap.dang_nhap(data.get("user"), data.get("pass"))
        time.sleep(3)  # để nhìn rõ
        # kiểm tra alert
        thong_bao = trang_dang_nhap.lay_thong_bao_alert()
        if thong_bao:
            print("Kết quả: ", thong_bao)
            continue
        # kiểm tra thành công
        if trang_dang_nhap.kiem_tra_dang_nhap_thanh_cong():
            print("Kết quả: Đăng nhập thành công")
        else:
            # kiểm tra lỗi form
            loi = trang_dang_nhap.lay_loi_form()
            if loi:
                print("Kết quả: ", loi)
            else:
                print("Kết quả: Đăng nhập thất bại")

    time.sleep(5)
    trinh_duyet.quit()
    print("kết thúc kiểm thử ")
if __name__ == "__main__":
    test()